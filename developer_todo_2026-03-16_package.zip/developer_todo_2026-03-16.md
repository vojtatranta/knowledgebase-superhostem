# Superhostem.cz - Developer To-Do

Date: 2026-03-16
Source: latest Google Doc feedback (`16.3.`), newer revision reviewed on 2026-03-16

## Goal

Convert the latest product feedback into a developer-ready MVP task list.

The implementation should stay aligned with the project brief:

- keep the product simple
- reduce setup friction for hosts
- improve reliability and clarity
- prioritize correct data and understandable UI states

## Priority Overview

### P1

1. Fix street number reset in the property address form
2. Fix the broken detailed guide link and make the setup CTA clearer
3. Add a way to test connection status
4. Clarify the red error state if it means access denied

### P2

5. Add monthly vs annual billing toggle with visible savings

### Future Increment

6. Add internal admin interface for host profile and subscription management

## Tasks

### 1. Fix street number reset in property address form

#### Problem

When the user enters the street number, the value appears correctly during input, but then resets back to empty.

#### Expected behavior

The full address, including street number, should persist after:

- typing
- blur
- save
- reload
- reopening the form

#### Developer checklist

- reproduce the bug in the property settings form
- inspect controlled input behavior and form state sync
- verify whether frontend normalization or validation clears the field
- verify the backend accepts and stores the street number correctly
- verify the stored value is returned correctly after refresh and revisit
- add regression coverage if tests exist in this area

#### Acceptance criteria

- street number does not disappear after entry
- the value remains saved after refresh or revisit
- address data is consistent in UI and persistence layer

#### Reference screenshot

![Street number field bug](./developer_todo_2026-03-16_assets/issue-1-street-number-bug.png)

### 2. Fix setup guidance visibility and broken detailed guide link

#### Problem

It is not obvious where the user should click to continue setup, and the detailed guide link currently leads nowhere.

#### Expected behavior

The primary setup action should be visually clear, and the detailed guide should open the correct configuration flow for calendar enrichment and email forwarding.

#### Developer checklist

- review the current CTA placement and styling
- make the main setup action more visually prominent
- identify why the detailed guide link fails and connect it to the correct destination
- ensure the destination explains the required setup clearly
- explain the difference between iCal-only setup and enriched email-based setup

#### Acceptance criteria

- users can easily identify the next setup step
- clicking the guide link opens the correct page
- the destination clearly explains what the user already has and what is missing
- the difference between basic iCal setup and enriched setup is easy to understand

#### Reference screenshots

![Setup screen reference 1](./developer_todo_2026-03-16_assets/issue-2-setup-link-screen-1.png)

![Setup screen reference 2](./developer_todo_2026-03-16_assets/issue-2-setup-link-screen-2.png)

### 3. Add a button to test the connection

#### Problem

There is currently no obvious button or action for testing whether the connection works.

#### Expected behavior

The user should be able to manually test the connection and get clear feedback about whether the integration is working.

#### Developer checklist

- identify which integration or setup step needs a test action
- add a clear `Test connection` button in the relevant setup screen
- return a visible success, failure, or pending state
- make sure the result helps the user understand what to do next

#### Acceptance criteria

- a visible connection test action exists
- the result state is understandable for non-technical users
- the user can tell whether setup is complete or blocked

#### Reference screenshot

![Missing test connection button](./developer_todo_2026-03-16_assets/issue-3-test-connection-missing.png)

### 4. Clarify the red error state

#### Problem

There is a red UI state that is unclear to the user. It may indicate an access denied condition, but the meaning is not obvious.

#### Expected behavior

Any red state should clearly explain:

- what went wrong
- whether it is an error, warning, or permission issue
- what the user should do next

#### Developer checklist

- identify the exact source of the red state
- confirm whether it means access denied, auth failure, validation issue, or another blocked state
- replace vague visual feedback with explicit copy
- ensure red is only used for real warning or error states

#### Acceptance criteria

- the user understands what the red state means
- the message includes a useful next step where possible
- error styling is reserved for genuine error or blocked states

#### Reference screenshot

![Unclear red error state](./developer_todo_2026-03-16_assets/issue-4-red-access-denied.png)

### 5. Add monthly vs annual billing toggle with savings visibility

#### Problem

There is no clear option to switch between monthly and annual billing, and annual savings are not visibly communicated.

#### Expected behavior

The pricing UI should allow the user to switch between monthly and annual plans and clearly show how much cheaper the annual option is.

#### Developer checklist

- add a visible monthly vs annual toggle or switch
- make the selected state obvious
- display the annual savings clearly when annual billing is selected
- keep the pricing explanation aligned with the project pricing model

#### Acceptance criteria

- the user can switch between monthly and annual pricing views
- the selected billing state is obvious
- annual savings are clearly visible and understandable

#### Reference screenshot

![Billing toggle missing](./developer_todo_2026-03-16_assets/issue-5-billing-toggle.png)

### 6. Future increment: admin interface for internal operations

#### Problem

There is no internal administrative interface for checking host profiles, subscription status, settings, and support workflows.

#### Expected behavior

In a future increment, internal users should be able to inspect host accounts, review subscription state, and access account context from one place.

#### Suggested scope

- host profile overview
- subscription visibility
- account and setup status
- property overview
- support-oriented account access or proxy workflow if needed

#### Note

This is not MVP-critical compared with the product-facing issues above, so it should be treated as a future increment rather than immediate delivery unless priorities change.

## Implementation Notes

- Keep solutions lightweight and avoid overengineering.
- Favor clarity in the UI over adding more complexity.
- Prioritize data correctness for the address issue.
- Error states should be explicit and actionable.
- Copy updates should match the MVP focus of operational clarity for hosts.

## Suggested QA Pass

- test property address editing end to end
- test setup flow from CTA to the detailed guide destination
- test connection feedback states
- test blocked or permission error states
- test pricing toggle behavior on desktop and mobile
